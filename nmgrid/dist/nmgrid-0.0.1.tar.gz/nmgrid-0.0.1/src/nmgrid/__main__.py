from .main import main, copyright

if __name__ == '__main__':
    copyright()
    main()